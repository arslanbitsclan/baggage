<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <?php echo $__env->yieldPushContent('head'); ?>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="">
    <meta property="og:type" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
    <!-- IZI Toast -->
    <link href="<?php echo e(asset('css/iziToast.css')); ?>" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/admin/imgs/theme/favicon.svg')); ?>">
    <!-- Template CSS -->
    <link href="<?php echo e(asset('assets/admin/css/main.css')); ?>" rel="stylesheet" type="text/css" />

    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>

</head>

<body>
    <div class="screen-overlay"></div>
    <aside class="navbar-aside" id="offcanvas_aside">
        <div class="aside-top">
            <a href="<?php echo e(url('/admin')); ?>" class="brand-wrap">
                <h4>Baggage Factory</h4>
            </a>
            <div>
                <button class="btn btn-icon btn-aside-minimize"> <i class="text-muted material-icons md-menu_open"></i>
                </button>
            </div>
        </div>
        <nav>
            <ul class="menu-aside">
                <li class="menu-item <?php if($active == 'dashboard'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(url('/admin')); ?>"> <i class="icon material-icons md-home"></i>
                        <span class="text">Dashboard</span>
                    </a>
                </li>
                <li class="menu-item <?php if($active == 'product'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(url('/admin/products')); ?>"> <i
                            class="icon material-icons md-shopping_bag"></i>
                        <span class="text">Products</span>
                    </a>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'order'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon material-icons md-shopping_cart"></i>
                        <span class="text">Orders</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(route('Admin.Reg-users-new-orders')); ?>">Register Users New Orders</a>
                        <a href="<?php echo e(route('Admin.Visitors-new-orders')); ?>">Visitors New Orders</a>
                        <a href="<?php echo e(route('Admin.Reg-users-orders')); ?>">Register Users Orders</a>
                        <a href="<?php echo e(route('Admin.Visitors-orders')); ?>">Visitors Orders</a>
                    </div>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'category'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon material-icons md-stars"></i>
                        <span class="text">Categories</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(url('/admin/categories')); ?>">Category</a>
                        <a href="<?php echo e(url('/admin/sub-categories')); ?>">Sub Category</a>
                        <a href="<?php echo e(url('/admin/brands')); ?>">Brands</a>
                        <a href="<?php echo e(url('/admin/attribute')); ?>">Attribute</a>
                        <a href="<?php echo e(url('/admin/attribute-value')); ?>">Attribute Value</a>
                        <a href="<?php echo e(url('/admin/blog-categories')); ?>">Blog Category</a>
                    </div>
                </li>
                <li class="menu-item <?php if($active == 'currency'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(url('/admin/currencies')); ?>"> <i
                            class="icon material-icons md-monetization_on"></i>
                        <span class="text">Currencies</span>
                    </a>
                </li>
                <li class="menu-item <?php if($active == 'admin'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(url('/admin/admins')); ?>"> <i
                            class="icon material-icons md-person"></i>
                        <span class="text">Admins</span>
                    </a>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'mail'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon bx bx-envelope"></i>
                        <span class="text">Mails</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(route('Admin.sent-mails')); ?>">Sent Mails</a>
                        <a href="<?php echo e(route('Admin.contact-us')); ?>">Contact Us</a>
                        <a href="<?php echo e(route('Admin.order-confirmation')); ?>">Order Confirmation Template</a>
                        <a href="<?php echo e(route('Admin.order-acceptence')); ?>">Order Acceptance Template</a>
                        <a href="<?php echo e(route('Admin.order-dispatching')); ?>">Order Dispatching Template</a>
                        <a href="<?php echo e(route('Admin.order-cancelation')); ?>">Order Cancelation Template</a>
                        <a href="<?php echo e(route('Admin.order-returning')); ?>">Order Returning Template</a>
                        <a href="<?php echo e(route('Admin.order-completion')); ?>">Order Completion Template</a>
                        <a href="<?php echo e(route('Admin.marketing')); ?>">Marketing Template</a>
                    </div>
                </li>
                <li class="menu-item <?php if($active == 'review'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(route('Admin.reviews')); ?>"> <i
                            class="icon material-icons md-comment"></i>
                        <span class="text">Reviews</span>
                    </a>
                </li>
                <li class="menu-item <?php if($active == 'blog'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(route('Admin.blogs')); ?>"> <i
                            class="icon material-icons md-stars"></i>
                        <span class="text">Blogs</span> </a>
                </li>
                <li class="menu-item <?php if($active == 'shipping'): ?> active <?php endif; ?>">
                    <a class="menu-link" href="<?php echo e(route('Admin.shipping-companies')); ?>"> <i class="icon bx bxs-truck"></i>
                        <span class="text">Shipping Companies</span>
                    </a>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'coupon'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon bx bxs-coupon"></i>
                        <span class="text">Coupons</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(route('Admin.coupons')); ?>">Coupons</a>
                        <a href="<?php echo e(route('Admin.used-coupons')); ?>">Used Coupons</a>
                    </div>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'cms'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon bx bxs-notepad"></i>
                        <span class="text">CMS</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(route('Admin.sent-mails')); ?>">Home</a>
                        <a href="<?php echo e(route('Admin.cms-about')); ?>">About</a>
                        <a href="<?php echo e(route('Admin.cms-shop')); ?>">Shop</a>
                        <a href="<?php echo e(route('Admin.cms-blog')); ?>">Blog</a>
                        <a href="<?php echo e(route('Admin.cms-privacy-policy')); ?>">Privacy Policy</a>
                        <a href="<?php echo e(route('Admin.cms-terms-conditions')); ?>">Terms & Conditions</a>
                        <a href="<?php echo e(route('Admin.cms-blog-detail')); ?>">Single Blog</a>
                        <a href="<?php echo e(route('Admin.cms-product-detail')); ?>">Single Product</a>
                    </div>
                </li>
                <li class="menu-item has-submenu <?php if($active == 'customer'): ?> active <?php endif; ?>">
                    <a class="menu-link"> <i class="icon material-icons md-person"></i>
                        <span class="text">Customers</span>
                    </a>
                    <div class="submenu">
                        <a href="<?php echo e(route('Admin.customers')); ?>">Customers</a>
                        <a href="<?php echo e(route('Admin.visitors')); ?>">Visitors</a>
                        <a href="<?php echo e(route('Admin.subscribers')); ?>">Subscribers</a>
                    </div>
                </li>
            </ul>
            <br>
            <br>
        </nav>
    </aside>
    <main class="main-wrap">
        <header class="main-header navbar">
            <div class="col-search"></div>
            <div class="col-nav">
                <button class="btn btn-icon btn-mobile me-auto" data-trigger="#offcanvas_aside"> <i
                        class="material-icons md-apps"></i> </button>
                <ul class="nav">
                    <li class="dropdown nav-item">
                        <a class="dropdown-toggle" data-bs-toggle="dropdown" href="#" id="dropdownAccount"
                            aria-expanded="false"> <img class="img-xs rounded-circle"
                                src="<?php echo e(asset('uploads/' . session()->get('admin.admin_media'))); ?>" alt="User"
                                onerror="this.src='<?php echo e(asset('assets/admin/imgs/people/avatar2.jpg')); ?>'"></a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownAccount">
                            <a class="dropdown-item" href="<?php echo e(route('Admin.edit-profile')); ?>"><i
                                    class="material-icons md-settings"></i>Account
                                Settings</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="<?php echo e(url('/admin/logout')); ?>"><i
                                    class="material-icons md-exit_to_app"></i>Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </header><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>