<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Customers | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Customers</h2>
                </div>
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <div class="row gx-3">
                        <div class="col-lg-5 col-md-5 me-auto">
                            <form class="searchform" method="POST" action="<?php echo e(route('Admin.used-coupons-term')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input list="search_terms" type="text" name="term" class="form-control"
                                        placeholder="Search by term">
                                    <button class="btn btn-light bg" type="submit"> <i
                                            class="material-icons md-search"></i></button>
                                </div>
                            </form>
                        </div>
                        <form class="col-lg-6 col-6 col-md-3 d-flex justify-content-end"
                            action="<?php echo e(route('Admin.used-coupons-post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-2 col-2 col-md-4">
                                <select class="form-select" name="record" onchange="this.form.submit()">
                                    <option value="20" <?php if($record_perpage == 20): echo 'selected'; endif; ?>>20</option>
                                    <option value="30" <?php if($record_perpage == 30): echo 'selected'; endif; ?>>30</option>
                                    <option value="40" <?php if($record_perpage == 40): echo 'selected'; endif; ?>>40</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </header>
                <!-- card-header end// -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Registered</th>
                                    <th class="text-end"> Action </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="javascript:void(0)" class="itemside">
                                                <div class="info pl-3">
                                                    <h6 class="mb-0 title"><?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></h6>
                                                    <small class="text-muted">Username: <?php echo e($customer->username); ?></small>
                                                </div>
                                            </a>
                                        </td>
                                        <td><?php echo e($customer->email_addr); ?></td>
                                        <td><?php echo e(Str::words($customer->created_at,10,'')); ?></td>
                                        <td class="text-end">
                                            <a class="btn btn-sm btn-danger rounded font-sm mt-15" id="dlt_btn_<?php echo e($customer->id); ?>" onclick="delete_customer(<?php echo e($customer->id); ?>)">Delete</a>
                                            <a class="bbtn btn-sm btn-danger rounded font-sm mt-15" type="button" id="loading_btn_<?php echo e($customer->id); ?>" hidden>
                                                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table> <!-- table-responsive.// -->
                    </div>
                </div> 
                <!-- card-body end// -->
            </div>
            <div class="pagination-area mt-30 mb-50">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-start">
                        <?php if(!empty($coupons)): ?>
                            <?php echo e($customers->render()); ?>

                        <?php endif; ?>

                    </ul>
                </nav>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            function delete_customer(id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('Admin.delete-customer')); ?>",
                    data: {
                        'id': id
                    },
                    type: 'POST',
                    beforeSend: function() {
                        $("#loading_btn_" + id).removeAttr('hidden');
                        $("#dlt_btn_" + id).hide();
                    },
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                            window.location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/customers.blade.php ENDPATH**/ ?>