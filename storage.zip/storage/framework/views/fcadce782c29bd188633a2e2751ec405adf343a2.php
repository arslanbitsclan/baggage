<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Edit Blog | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel='stylesheet' href='https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/dist/bootstrap-tagsinput.css'>
        <script src="https://cdn.tiny.cloud/1/6mwwhw1qnclmda4v5y7vmobvi2ieeyszxm98vjsqbacuc198/tinymce/6/tinymce.min.js"
            referrerpolicy="origin"></script>
        <style type="text/css">
            .bootstrap-tagsinput .tag {
                margin-right: 2px;
                color: white !important;
                background-color: #088178;
                padding: .2em .6em .3em;
                font-size: 100%;
                vertical-align: baseline;
                border-radius: .25em;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <form action="<?php echo e(route('Admin.update-blog')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12">
                        <div class="content-header">
                            <h2 class="content-title">Edit Blog</h2>
                            <div>
                                <input type="hidden" name="id" value="<?php echo e($blog->id); ?>" />
                                <input type="submit" class="btn btn-md rounded font-sm hover-up" value="Update" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h4>Basic</h4>
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <label for="name" class="form-label">Blog title</label>
                                    <input type="text" placeholder="Type here" class="form-control"
                                        value="<?php echo e($blog->title); ?>" id="name" name="name" required>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label">Blog Categories</label>
                                    <select class="form-select" id="category" name="category" required>
                                        <?php $__currentLoopData = $blog_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($blog_category->id); ?>" <?php if($blog_category->id == $blog->blog_categories_id): echo 'selected'; endif; ?>>
                                                <?php echo e($blog_category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label">Blog Priority</label>
                                    <select class="form-select" id="priority" name="priority">
                                        <option value="0" <?php if($blog->trending_priority == '0'): echo 'selected'; endif; ?>>0</option>
                                        <option value="1" <?php if($blog->trending_priority == '1'): echo 'selected'; endif; ?>>1</option>
                                        <option value="2" <?php if($blog->trending_priority == '2'): echo 'selected'; endif; ?>>2</option>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label for="content" class="form-label">Short description</label>
                                    <input type="text" placeholder="Type here" class="form-control"
                                        value="<?php echo e($blog->short_description); ?>" id="content" name="content">
                                </div>
                                <div class="mb-4">
                                    <label class="form-label">Full description</label>
                                    <textarea placeholder="Type here" class="form-control" rows="4" id="description" name="description"><?php echo $blog->description; ?></textarea>
                                </div>
                            </div>
                        </div> <!-- card end// -->
                    </div>
                    <div class="col-lg-5">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h4>Media</h4>
                            </div>
                            <div class="card-body">
                                <div class="input-upload">
                                    <div id="main_img_div">
                                        <img id="main_img" src="<?php echo e(asset('uploads/' . $blog->media)); ?>" alt="">
                                    </div>
                                    <label for="main_img" class="form-label">Main Image</label>
                                    <input class="form-control" type="file" id="main_media" name="main_media"
                                        onchange="readURL(this);" />
                                </div>
                            </div>
                        </div> <!-- card end// -->
                    </div>
                </div>
            </form>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script src='https://bootstrap-tagsinput.github.io/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js'></script>
        <script>
            tinymce.init({
                selector: 'textarea',
                plugins: 'a11ychecker advcode casechange export formatpainter image editimage linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tableofcontents tinycomments tinymcespellchecker',
                toolbar: 'a11ycheck addcomment showcomments casechange checklist code export formatpainter image editimage pageembed permanentpen table tableofcontents',
                toolbar_mode: 'floating',
                tinycomments_mode: 'embedded',
                tinycomments_author: 'Author name',
            });

            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#main_img')
                            .attr('src', e.target.result);
                    };

                    reader.readAsDataURL(input.files[0]);
                }
            }
        </script>
        <script>
            $(function() {
                $('#tags').on('change', function(event) {

                    var $element = $(event.target);
                    var $container = $element.closest('.example');

                    if (!$element.data('tagsinput'))
                        return;

                    var val = $element.val();
                    if (val === null)
                        val = "null";
                    var items = $element.tagsinput('items');

                    $('code', $('pre.val', $container)).html(($.isArray(val) ? JSON.stringify(val) : "\"" + val
                        .replace('"', '\\"') + "\""));
                    $('code', $('pre.items', $container)).html(JSON.stringify($element.tagsinput('items')));


                }).trigger('change');
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/editBlog.blade.php ENDPATH**/ ?>