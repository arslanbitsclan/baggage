<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Shipping Companies | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Shipping Companies </h2>
                    <p>Add or delete a shipping company</p>
                </div>
                <div>
                    <input type="text" placeholder="Search Categories" class="form-control bg-white">
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <form action="<?php echo e(route('Admin.add-shipping-company')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-4">
                                    <label for="product_name" class="form-label">Name</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="name" name="name" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="slug" class="form-label">Tracking URL</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="tracking_url" name="tracking_url" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['tracking_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="show" class="form-label">Enable/Disable</label>
                                    <select class="form-select" id="show" name="show" required>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['show'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="d-grid">
                                    <button class="btn btn-primary" type="submit">Add Shipping Company</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-9">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Tracking URL</th>
                                            <th>Is Enable</th>
                                            <th class="text-end">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><b><?php echo e($company->name); ?></b></td>
                                                <td><?php echo e($company->tracking_url); ?></td>
                                                <td>
                                                    <div class="mb-1">
                                                        <select class="form-select" id="show_select_<?php echo e($company->id); ?>"
                                                            onchange="show_company(<?php echo e($company->id); ?>)">
                                                            <option value="Yes"
                                                                <?php if($company->is_enable == 'Yes'): ?> Selected <?php endif; ?>>Yes
                                                            </option>
                                                            <option value="No"
                                                                <?php if($company->is_enable == 'No'): ?> Selected <?php endif; ?>>No
                                                            </option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td class="text-end">
                                                    <div class="dropdown">
                                                        <a data-bs-toggle="dropdown"
                                                            class="btn btn-light rounded btn-sm font-sm"> <i
                                                                class="material-icons md-more_horiz"></i> </a>
                                                        <div class="dropdown-menu">
                                                            <a class="dropdown-item text-danger"
                                                                onclick="delete_company(<?php echo e($company->id); ?>)">Delete</a>
                                                        </div>
                                                    </div> <!-- dropdown //end -->
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div> <!-- .col// -->
                    </div> <!-- .row // -->
                </div> <!-- card body .// -->
            </div> <!-- card .// -->
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            function show_company(id) {
                $.ajax({
                    url: "<?php echo e(route('Admin.show-shipping-company')); ?>",
                    data: {
                        'id': id,
                        'status': $('#show_select_' + id + ' option:selected').val()
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
            function delete_company(id) {                
                $.ajax({
                    url: "<?php echo e(route('Admin.delete-shipping-company')); ?>",
                    data: {
                        'id': id
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                            location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/shippingCompanies.blade.php ENDPATH**/ ?>