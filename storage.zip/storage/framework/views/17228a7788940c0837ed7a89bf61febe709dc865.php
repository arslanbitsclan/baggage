
<?php $__env->startPush('head'); ?>
    <title>About | Baggage Factory</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
    <?php
        $content = \App\Models\CMS::where('page', '=', 'about')->first();
    ?>
    <main class="main single-page">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(url('/')); ?>" rel="nofollow">Home</a>
                    <span></span> About us
                </div>
            </div>
        </div>
        <section class="section-padding">
            <div class="container pt-25">
                <div class="row">
                    <div class="align-self-center mb-lg-0 mb-4">
                        <h6 class="mt-0 mb-15 text-uppercase font-sm text-brand wow fadeIn animated">Our Company</h6>
                        <?php echo $content->content; ?>

                    </div>
                </div>
            </div>
        </section>
        <?php if($content->ad_status == 'Show'): ?>
            <section class="mt-50 mb-50">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="container">
                                <div class="banner-img banner-big wow fadeIn animated f-none">
                                    <img src="<?php echo e(asset('/uploads/' . $content->ad)); ?>" alt="">
                                    <div class="banner-text d-md-block d-none" style="margin-left: -2%;margin-top: 9.1%;">
                                        <a href="<?php if(empty($content->category_slug) && empty($content->sub_category_slug)): ?> <?php echo e(url('/shop')); ?>

                                            <?php elseif(!empty($content->category_slug) && empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug)); ?>

                                            <?php elseif(!empty($content->category_slug) && !empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug . '/' . $content->sub_category_slug)); ?> <?php endif; ?>"
                                            class="btn ">Learn More <i class="fi-rs-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/about.blade.php ENDPATH**/ ?>