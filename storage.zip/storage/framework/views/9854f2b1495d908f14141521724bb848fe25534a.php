<?php $__env->startSection('section'); ?>
    <?php
        $product = $product->toArray();
        $categories2 = $categories->toArray();
        $sub_categories2 = $sub_categories_for_bread->toArray();
        $price = 0;
        $images = explode(',', $product[0]['suppornting_media']);
        if (empty($images[count($images) - 1])) {
            unset($images[count($images) - 1]);
        }
        $sum_of_rating = \App\Models\Reviews::selectRaw('SUM(rating) as sum')
            ->where('products_id', '=', $product[0]['id'])
            ->where('status', '=', 'Approved')
            ->first()->sum;
        $avg_of_rating = \App\Models\Reviews::selectRaw('SUM(rating)/COUNT(products_id) as avg')
            ->where('products_id', '=', $product[0]['id'])
            ->where('status', '=', 'Approved')
            ->first()->avg;
        $star_rating = \App\Models\Reviews::select(DB::raw('COUNT(rating) as rating'), 'rating as star')
            ->where('products_id', '=', $product[0]['id'])
            ->where('status', '=', 'Approved')
            ->groupBy('rating')
            ->orderBy('rating')
            ->get();
    ?>
    <?php $__env->startPush('head'); ?>
        <title><?php echo e($product[0]['title']); ?> | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <style>
            .c-text {
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 1;
                /* number of lines to show */
                -webkit-box-orient: vertical;
            }

            .star-rating {
                line-height: 32px;
                font-size: 1.25em;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <?php
        $content = \App\Models\CMS::where('page', '=', 'product_detail')->first();
    ?>
    <main class="main">
        <?php $__currentLoopData = $categories2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category['id'] == $product[0]['cat_id']): ?>
                <?php $__currentLoopData = $sub_categories2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sub_category['id'] == $product[0]['sub_cat_id']): ?>
                        <div class="page-header breadcrumb-wrap">
                            <div class="container">
                                <div class="breadcrumb">
                                    <a href="<?php echo e(url('/shop/' . $category['category_slug'])); ?>"
                                        rel="nofollow"><?php echo e($category['category_title']); ?></a>
                                    <span></span> <a
                                        href="<?php echo e(url('/shop/' . $category['category_slug'] . '/' . $sub_category['sub_category_slug'])); ?>"
                                        rel="nofollow"><?php echo e($sub_category['sub_category_title']); ?></a>
                                    <span></span> <?php echo e($product[0]['title']); ?>

                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="product-detail accordion-detail">
                            <div class="row mb-50">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="detail-gallery">
                                        <span class="zoom-icon"><i class="fi-rs-search"></i></span>
                                        <!-- MAIN SLIDES -->
                                        <div class="product-image-slider">
                                            <figure class="border-radius-10">
                                                <img src="<?php echo e(asset('uploads/' . $product[0]['main_media'])); ?>"
                                                    alt="product image">
                                            </figure>
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <figure class="border-radius-10">
                                                    <img src="<?php echo e(asset('uploads/' . $image)); ?>" alt="product image">
                                                </figure>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <!-- THUMBNAILS -->
                                        <div class="slider-nav-thumbnails pl-15 pr-15">
                                            <div><img src="<?php echo e(asset('uploads/' . $product[0]['main_media'])); ?>"
                                                    alt="product image"></div>
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div><img src="<?php echo e(asset('uploads/' . $image)); ?>" alt="product image"></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <!-- End Gallery -->
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="detail-info">
                                        <h2 class="title-detail"><?php echo e($product[0]['title']); ?></h2>
                                        <div class="product-detail-rating">
                                            <div class="pro-details-brand">
                                                <span> Category: <a href="shop-grid-right.html">
                                                        <?php $__currentLoopData = $categories2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($category['id'] == $product[0]['cat_id']): ?>
                                                                <?php echo e($category['category_title']); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </a></span>
                                            </div>
                                            <div class="product-rate-cover text-end">
                                                <?php if(count($reviews) > 0): ?>
                                                    <div class="d-inline-block">
                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                            <?php if($i < $avg_of_rating): ?>
                                                                <span class="fa fa-star text-warning"></span>
                                                            <?php else: ?>
                                                                <span class="fa fa-star"></span>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <span class="font-small ml-5 text-muted"> (<?php echo e(count($reviews)); ?>

                                                        reviews)</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="clearfix product-price-cover">
                                            <div class="product-price primary-color float-left">
                                                <?php if(!empty($product[0]['sale_price'])): ?>
                                                    <?php
                                                        $price = $product[0]['sale_price'];
                                                    ?>
                                                    <ins><span class="text-brand"
                                                            id="p_price"><?php echo e(currency_converter($product[0]['sale_price'])); ?></span></ins>
                                                    <ins><span
                                                            class="old-price font-md ml-15"><?php echo e(currency_converter($product[0]['price'])); ?></span></ins>
                                                    <input id="pro_price_<?php echo e($product[0]['id']); ?>" type="hidden"
                                                        value="<?php echo e($product[0]['sale_price']); ?>" />
                                                <?php else: ?>
                                                    <?php
                                                        $price = $product[0]['price'];
                                                    ?>
                                                    <ins><span class="text-brand"
                                                            id="p_price"><?php echo e(currency_converter($product[0]['price'])); ?></span></ins>
                                                    <input id="pro_price_<?php echo e($product[0]['id']); ?>" type="hidden"
                                                        value="<?php echo e($product[0]['price']); ?>" />
                                                <?php endif; ?>
                                                <?php if(!empty($product[0]['sale_in_percentage'])): ?>
                                                    <span
                                                        class="save-price  font-md color3 ml-15"><?php echo e($product[0]['sale_in_percentage']); ?>%
                                                        Off</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="bt-1 border-color-1 mt-15 mb-15"></div>
                                        <div class="short-desc mb-30">
                                            <p><?php echo e($product[0]['content']); ?></p>
                                        </div>
                                        <!-- <div class="product_sort_info font-xs mb-30">
                                            <ul>
                                                <li class="mb-10"><i class="fi-rs-refresh mr-5"></i> 30 Day Return Policy
                                                </li>
                                                <li><i class="fi-rs-credit-card mr-5"></i> Cash on Delivery available</li>
                                            </ul>
                                        </div> -->
                                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(in_array($attribute->id, $attribute_array)): ?>
                                                <div class="attr-detail attr-color mb-15">
                                                    <strong class="mr-10"><?php echo e($attribute->name); ?></strong>
                                                    <ul class="list-filter size-filter font-small">
                                                        <?php $__currentLoopData = $attribute->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(in_array($attributeValue->id, $attribute_value_array)): ?>
                                                                <li><label class="form-check">
                                                                        <input class="form-check-input"
                                                                            id="attribute_<?php echo e($attributeValue->id); ?>"
                                                                            name="<?php echo e($attribute->name); ?>"
                                                                            value="<?php echo e($attributeValue->value); ?>"
                                                                            type="<?php echo e($attribute->widget); ?>"
                                                                            onclick="change_price(<?php echo e($price); ?>,<?php echo e($attribute_price[$attributeValue->id]); ?>)">
                                                                        <span class="form-check-label">
                                                                            <?php echo e($attributeValue->value); ?> </span>
                                                                    </label></li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="bt-1 border-color-1 mt-30 mb-30"></div>
                                        <div class="detail-extralink">
                                            <div class="detail-qty border radius" style="padding: 0px">
                                                <input type="number" class="border-0" id="qty_val_<?php echo e($product[0]['id']); ?>"
                                                    min="1" max="<?php echo e($product[0]['quantity']); ?>" value="1" />
                                            </div>
                                            <div class="product-extra-link2">
                                                <button type="submit" class="button button-add-to-cart"
                                                    onclick="addToCart(<?php echo e($product[0]['id']); ?>)">Add to
                                                    cart</button>
                                                <a aria-label="Add To Wishlist" class="action-btn hover-up"
                                                    href="javascript:void(0)"
                                                    onclick="addToWishlist(<?php echo e($product[0]['id']); ?>)"><i
                                                        class="fi-rs-heart"></i></a>
                                            </div>
                                        </div>
                                        <ul class="product-meta font-xs color-grey mt-50">
                                            
                                            <?php
                                                $tags = explode(',', $product[0]['tags']);
                                                if (empty($tags[count($tags) - 1])) {
                                                    unset($tags[count($tags) - 1]);
                                                }
                                                $last_tag = count($tags) - 1;
                                                $i_t = 0;
                                            ?>
                                            <li class="mb-5">Tags:
                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($tag[$i_t] != $tag[$last_tag]): ?>
                                                        <a href="javascript:void(0)"
                                                            rel="tag"><?php echo e($tag); ?></a>,
                                                    <?php else: ?>
                                                        <a href="javascript:void(0)" rel="tag"><?php echo e($tag); ?></a>
                                                    <?php endif; ?>
                                                    <?php
                                                        $i_t++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <li>Availability:<span
                                                    class="in-stock text-success ml-5"><?php echo e($product[0]['quantity']); ?>

                                                    Items In
                                                    Stock</span></li>
                                        </ul>
                                    </div>
                                    <!-- Detail Info -->
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-10 m-auto entry-main-content">
                                    <h2 class="section-title style-1 mb-30">Description</h2>
                                    <div class="description mb-50"><?php echo $product[0]['description']; ?></div>
                                    <div class="social-icons single-share">
                                        <ul class="text-grey-5 d-inline-block">
                                            <li><strong class="mr-10">Share this:</strong></li>
                                            <li class="social-facebook"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-facebook.svg')); ?>"
                                                        alt=""></a></li>
                                            <li class="social-twitter"> <a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-twitter.svg')); ?>"
                                                        alt=""></a></li>
                                            <li class="social-instagram"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-instagram.svg')); ?>"
                                                        alt=""></a></li>
                                            <li class="social-linkedin"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-pinterest.svg')); ?>"
                                                        alt=""></a></li>
                                        </ul>
                                    </div>
                                    <?php if(count($reviews) > 0): ?>
                                        <h3 class="section-title style-1 mb-30 mt-30">Reviews (<?php echo e(count($reviews)); ?>)</h3>
                                        <!--Comments-->
                                        <div class="comments-area style-2">
                                            <div class="row">
                                                <div class="col-lg-8">
                                                    <div class="comment-list">
                                                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="single-comment justify-content-between d-flex">
                                                                <div class="user justify-content-between d-flex">
                                                                    <div class="thumb text-center">
                                                                        <h6><a
                                                                                href="javascript:void(0)"><?php echo e($review->name); ?></a>
                                                                        </h6>
                                                                    </div>
                                                                    <div class="desc">
                                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                                            <?php if($i < floatval($review->rating)): ?>
                                                                                <span
                                                                                    class="fa fa-star text-warning"></span>
                                                                            <?php else: ?>
                                                                                <span class="fa fa-star"></span>
                                                                            <?php endif; ?>
                                                                        <?php endfor; ?>
                                                                        <p><?php echo e($review->comment); ?>

                                                                        </p>
                                                                        <div class="d-flex justify-content-between">
                                                                            <div class="d-flex align-items-center">
                                                                                <p class="font-xs mr-30">
                                                                                    <?php echo e(formatted_date($review->created_at, 'Y-d-m')); ?>

                                                                                    at
                                                                                    <?php echo e(formatted_date($review->created_at, 'h:m a')); ?>

                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <h4 class="mb-30">Customer reviews</h4>
                                                    <div class="d-flex mb-30">
                                                        <div class="d-inline-block mr-15">
                                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                                <?php if($i < floatval($avg_of_rating)): ?>
                                                                    <span class="fa fa-star text-warning"></span>
                                                                <?php else: ?>
                                                                    <span class="fa fa-star"></span>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                        </div>
                                                        <h6 class="mt-2"><?php echo e(floatval($avg_of_rating)); ?> out of 5</h6>
                                                    </div>
                                                    <?php $__currentLoopData = $star_rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="progress">
                                                            <span><?php echo e($item->star); ?> star</span>
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo e(intval(($item->rating / $sum_of_rating) * 100)); ?>%;"
                                                                aria-valuenow="<?php echo e(intval(($item->rating / $sum_of_rating) * 100)); ?>"
                                                                aria-valuemin="0" aria-valuemax="100">
                                                                <?php echo e(intval(($item->rating / $sum_of_rating) * 100)); ?>%
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <!--comment form-->
                                    <div class="comment-form">
                                        <h4 class="mb-15">Add a review</h4>
                                        <div class="row">
                                            <div class="col-lg-8 col-md-12">
                                                <form class="form-contact comment_form" action="<?php echo e(route('rating')); ?>"
                                                    id="commentForm" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="star-rating">
                                                        <span class="fa fa-star" data-rating="1"></span>
                                                        <span class="fa fa-star" data-rating="2"></span>
                                                        <span class="fa fa-star" data-rating="3"></span>
                                                        <span class="fa fa-star" data-rating="4"></span>
                                                        <span class="fa fa-star" data-rating="5"></span>
                                                        <input type="hidden" name="product_rating" class="rating-value"
                                                            value="1" required>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <textarea class="form-control w-100" name="comment" id="comment" cols="30" rows="9"
                                                                    placeholder="Write Comment" required></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <input class="form-control" name="name" id="name"
                                                                    type="text" placeholder="Name" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group">
                                                                <input class="form-control" name="email" id="email"
                                                                    type="email" placeholder="Email" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <input type="hidden" value="<?php echo e($product[0]['id']); ?>"
                                                            name="id" />
                                                        <button type="submit" class="button button-contactForm">Submit
                                                            Review</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-60">
                                <div class="col-12">
                                    <h3 class="section-title style-1 mb-30">Related products</h3>
                                </div>
                                <div class="col-12">
                                    <div class="row related-products">
                                        <div class="carausel-4-columns-cover position-relative">
                                            <div class="slider-arrow slider-arrow-2 carausel-4-columns-arrow"
                                                id="carausel-4-columns-1-arrows">
                                            </div>
                                            <div class="carausel-4-columns carausel-arrow-center"
                                                id="carausel-4-columns-1">
                                                <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-3 col-md-4 col-12 col-sm-6 m-2">
                                                        <div class="product-cart-wrap mb-30">
                                                            <div class="product-img-action-wrap">
                                                                <div class="product-img product-img-zoom">
                                                                    <a
                                                                        href="<?php echo e(url('/product-detail/' . $related_product->id)); ?>">
                                                                        <?php
                                                                            $image = explode(',', $related_product->suppornting_media);
                                                                        ?>
                                                                        <img class="default-img"
                                                                            src="<?php echo e(asset('uploads/' . $related_product->main_media)); ?>"
                                                                            alt="">
                                                                        <img class="hover-img"
                                                                            src="<?php echo e(asset('uploads/' . $image[0])); ?>"
                                                                            alt="">
                                                                    </a>
                                                                </div>
                                                                <div class="product-action-1">
                                                                    <a aria-label="Quick view" class="action-btn hover-up"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#Modal<?php echo e($related_product->id); ?>">
                                                                        <i class="fi-rs-eye"></i></a>
                                                                    <a aria-label="Add To Wishlist"
                                                                        class="action-btn hover-up"
                                                                        href="javascript:void(0)"
                                                                        onclick="addToWishlist(<?php echo e($related_product->id); ?>)"><i
                                                                            class="fi-rs-heart"></i></a>
                                                                </div>
                                                                <?php
                                                                    $badges = explode(',', $related_product->badges);
                                                                    $space = 0;
                                                                ?>
                                                                <?php $__currentLoopData = $badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($badge == 'Hot'): ?>
                                                                        <div class="product-badges product-badges-position product-badges-mrg"
                                                                            style="margin-top: <?php echo e($space); ?>%;">
                                                                            <span class="hot">Hot</span>
                                                                        </div>
                                                                    <?php elseif($badge == 'New'): ?>
                                                                        <div class="product-badges product-badges-position product-badges-mrg"
                                                                            style="margin-top: <?php echo e($space); ?>%;">
                                                                            <span class="new">New</span>
                                                                        </div>
                                                                    <?php elseif($badge == 'Best Sell'): ?>
                                                                        <div class="product-badges product-badges-position product-badges-mrg"
                                                                            style="margin-top: <?php echo e($space); ?>%;">
                                                                            <span class="best">Best Sell</span>
                                                                        </div>
                                                                    <?php elseif($badge == 'Featured'): ?>
                                                                        <div class="product-badges product-badges-position product-badges-mrg"
                                                                            style="margin-top: <?php echo e($space); ?>%;">
                                                                            <span class="hot">Featured</span>
                                                                        </div>
                                                                    <?php elseif($badge == 'Sale'): ?>
                                                                        <div class="product-badges product-badges-position product-badges-mrg"
                                                                            style="margin-top: <?php echo e($space); ?>%;">
                                                                            <span class="sale">Sale</span>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <?php
                                                                        $space = $space + 9;
                                                                    ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                            <div class="product-content-wrap">
                                                                <div class="product-category">
                                                                    <a href="<?php echo e(url('/shop')); ?>">
                                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($category->id == $related_product->cat_id): ?>
                                                                                <?php echo e($category->category_title); ?>

                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </a>
                                                                </div>
                                                                <h2 class="c-text" title="<?php echo e($related_product->title); ?>">
                                                                    <a
                                                                        href="<?php echo e(url('/product-detail/' . $related_product->id)); ?>"><?php echo e($related_product->title); ?></a>
                                                                </h2>
                                                                <div class="rating-result" title="90%">
                                                                    <span>
                                                                        <span>90%</span>
                                                                    </span>
                                                                </div>
                                                                <div class="product-price">
                                                                    <?php
                                                                        $price = 0;
                                                                    ?>
                                                                    <?php if($related_product->sale_price > 0): ?>
                                                                        <span>
                                                                            <?php echo e(currency_converter($related_product->sale_price)); ?></span>
                                                                        <span
                                                                            class="old-price"><?php echo e(currency_converter($related_product->price)); ?></span>
                                                                        <?php
                                                                            $price = $related_product->sale_price;
                                                                        ?>
                                                                    <?php else: ?>
                                                                        <span>
                                                                            <?php echo e(currency_converter($related_product->price)); ?></span>
                                                                        <?php
                                                                            $price = $related_product->price;
                                                                        ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="product-action-1 show">
                                                                    <a aria-label="Add To Cart"
                                                                        class="action-btn hover-up"
                                                                        href="javascript:void(0)"
                                                                        onclick="addToCart(<?php echo e($related_product->id); ?>,<?php echo e($price); ?>,1)"><i
                                                                            class="fi-rs-shopping-bag-add"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($content->ad_status == 'Show'): ?>
                            <div class="container">
                                <div class="banner-img banner-big wow fadeIn animated f-none">
                                    <img src="<?php echo e(asset('/uploads/' . $content->ad)); ?>" alt="">
                                    <div class="banner-text d-md-block d-none" style="margin-left: -2%;margin-top: 9.1%;">
                                        <a href="<?php if(empty($content->category_slug) && empty($content->sub_category_slug)): ?> <?php echo e(url('/shop')); ?>

                                            <?php elseif(!empty($content->category_slug) && empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug)); ?>

                                            <?php elseif(!empty($content->category_slug) && !empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug . '/' . $content->sub_category_slug)); ?> <?php endif; ?>"
                                            class="btn ">Learn More <i class="fi-rs-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            </div>
        </section>
        <section>
            <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $images = explode(',', $product->suppornting_media);
                    if (empty($images[count($images) - 1])) {
                        unset($images[count($images) - 1]);
                    }
                ?>
                <div class="modal fade custom-modal" id="Modal<?php echo e($product->id); ?>" tabindex="-1"
                    aria-labelledby="quickViewModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <div class="detail-gallery">
                                            <span class="zoom-icon"><i class="fi-rs-search"></i></span>
                                            <!-- MAIN SLIDES -->
                                            <div class="product-image-slider">
                                                <figure class="border-radius-10">
                                                    <img src="<?php echo e(asset('uploads/' . $product->main_media)); ?>"
                                                        alt="product image">
                                                </figure>
                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <figure class="border-radius-10">
                                                        <img src="<?php echo e(asset('uploads/' . $image)); ?>" alt="product image">
                                                    </figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <!-- THUMBNAILS -->
                                            <div class="slider-nav-thumbnails pl-15 pr-15">
                                                <div><img src="<?php echo e(asset('uploads/' . $product->main_media)); ?>"
                                                        alt="product image"></div>
                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div><img src="<?php echo e(asset('uploads/' . $image)); ?>" alt="product image">
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <!-- End Gallery -->
                                        <div class="social-icons single-share">
                                            <ul class="text-grey-5 d-inline-block">
                                                <li><strong class="mr-10">Share this:</strong></li>
                                                <li class="social-facebook"><a href="#"><img
                                                            src="assets/imgs/theme/icons/icon-facebook.svg"
                                                            alt=""></a></li>
                                                <li class="social-twitter"> <a href="#"><img
                                                            src="assets/imgs/theme/icons/icon-twitter.svg"
                                                            alt=""></a></li>
                                                <li class="social-instagram"><a href="#"><img
                                                            src="assets/imgs/theme/icons/icon-instagram.svg"
                                                            alt=""></a></li>
                                                <li class="social-linkedin"><a href="#"><img
                                                            src="assets/imgs/theme/icons/icon-pinterest.svg"
                                                            alt=""></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <div class="detail-info">
                                            <h3 class="title-detail mt-30"><?php echo e($product->title); ?></h3>
                                            <div class="product-detail-rating">
                                                <?php if(!empty($product->brand_id)): ?>
                                                    <div class="pro-details-brand">
                                                        <span> Brands: <a
                                                                href="shop-grid-right.html"><?php echo e($product->brand->name); ?></a></span>
                                                    </div>
                                                <?php endif; ?>
                                                <?php
                                                    $count_of_rating = \App\Models\Reviews::selectRaw('Count(products_id) as count')
                                                        ->where('products_id', '=', $product->id)
                                                        ->where('status', '=', 'Approved')
                                                        ->first()->count;
                                                    $avg_of_rating = \App\Models\Reviews::selectRaw('SUM(rating)/COUNT(products_id) as avg')
                                                        ->where('products_id', '=', $product->id)
                                                        ->where('status', '=', 'Approved')
                                                        ->first()->avg;
                                                ?>
                                                <div class="product-rate-cover text-end">
                                                    <div class="d-inline-block">
                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                            <?php if($i < floatval($avg_of_rating)): ?>
                                                                <span class="fa fa-star text-warning"></span>
                                                            <?php else: ?>
                                                                <span class="fa fa-star"></span>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <span class="font-small ml-5 text-muted"> (<?php echo e($count_of_rating); ?>

                                                        reviews)</span>
                                                </div>
                                            </div>
                                            <div class="clearfix product-price-cover">
                                                <div class="product-price primary-color float-left">
                                                    <?php if(!empty($product->sale_price)): ?>
                                                        <?php
                                                            $price = $product->sale_price;
                                                        ?>
                                                        <ins><span class="text-brand"
                                                                id="p_price"><?php echo e(currency_converter($product->sale_price)); ?></span></ins>
                                                        <ins><span
                                                                class="old-price font-md ml-15"><?php echo e(currency_converter($product->price)); ?></span></ins>
                                                    <?php else: ?>
                                                        <?php
                                                            $price = $product->price;
                                                        ?>
                                                        <ins><span class="text-brand"
                                                                id="p_price"><?php echo e(currency_converter($product->price)); ?></span></ins>
                                                    <?php endif; ?>
                                                    <?php if(!empty($product->sale_in_percentage)): ?>
                                                        <span
                                                            class="save-price  font-md color3 ml-15"><?php echo e($product->sale_in_percentage); ?>%
                                                            Off</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if(!empty($product->content)): ?>
                                                <div class="bt-1 border-color-1 mt-15 mb-15"></div>
                                                <div class="short-desc mb-30">
                                                    <p class="font-sm"><?php echo e($product->content); ?></p>
                                                </div>
                                                <div class="bt-1 border-color-1 mt-30 mb-30"></div>
                                            <?php endif; ?>
                                            <ul class="product-meta font-xs color-grey mt-50">
                                                <li class="mb-5">SKU: <a href="#"><?php echo e($product->sku); ?></a></li>
                                                <li class="mb-5">Tags: <a href="#" rel="tag">Cloth</a>, <a
                                                        href="#" rel="tag">Women</a>, <a href="#"
                                                        rel="tag">Dress</a> </li>
                                                <li>Availability:<span
                                                        class="in-stock text-success ml-5"><?php echo e($product->quantity); ?> Items
                                                        In Stock</span></li>
                                            </ul>
                                        </div>
                                        <!-- Detail Info -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
    <script>
        var $star_rating = $('.star-rating .fa');

        var SetRatingStar = function() {
            return $star_rating.each(function() {
                if (parseInt($star_rating.siblings('input.rating-value').val()) >= parseInt($(this).data(
                        'rating'))) {
                    return $(this).removeClass('fa-star').addClass('fa-star text-warning');
                } else {
                    return $(this).removeClass('fa-star text-warning').addClass('fa-star');
                }
            });
        };

        $star_rating.on('click', function() {
            $star_rating.siblings('input.rating-value').val($(this).data('rating'));
            return SetRatingStar();
        });

        SetRatingStar();
        $(document).ready(function() {

        });
    </script>
    <script>
        function change_price(product_price, price) {
            var new_price = product_price + price;
            $("#p_price").text('$' + new_price);
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function addToCart(id, price = 0, qty = 1) {
            if (price == 0 && qty == 1) {
                price = $('#pro_price_' + id).val();
                qty = $('#qty_val_' + id).val()
            }
            $.ajax({
                method: "post",
                url: "<?php echo e(url('/AddToCart')); ?>",
                data: {
                    "product_id": id,
                    "product_price": price,
                    "product_qty": qty
                },
                success: function(response) {
                    if (response.success) {
                        iziToast.success({
                            position: 'topRight',
                            message: response.message
                        });
                        $('#cartheading').html(response.qty);
                    } else {
                        iziToast.warning({
                            position: 'topRight',
                            message: response.message
                        });
                    }
                }
            });
        }

        function addToWishlist(id) {
            $.ajax({
                method: "post",
                url: "<?php echo e(url('/AddToWishlist')); ?>",
                data: {
                    "product_id": id,
                },
                success: function(response) {
                    if (response.success) {
                        iziToast.success({
                            position: 'topRight',
                            message: response.message
                        });
                        $('#wishlistheading').html(response.qty)
                    } else {
                        iziToast.warning({
                            position: 'topRight',
                            message: response.message
                        });
                    }
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/product-detail.blade.php ENDPATH**/ ?>