<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Contact Us Messages | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Contact Us Messages</h2>
                </div>
            </div>
            <?php if(count($messages)>0): ?>
                <div class="card mb-4">
                    <header class="card-header">
                        <div class="row gx-3">
                            <div class="col-lg-9 col-md-9 me-auto">
                            </div>
                            <div class="col-lg-3 col-3 col-md-3 d-flex justify-content-end">
                                <div class="col-lg-3 col-3 col-md-3">
                                    <form method="POST" action="<?php echo e(route('Admin.contact-us-page')); ?>" class="row">
                                        <?php echo csrf_field(); ?>
                                        <select class="form-select" name="record" onchange="this.form.submit()">
                                            <option value="20" <?php if($record_perpage=="20"): echo 'selected'; endif; ?>>20</option>
                                            <option value="30" <?php if($record_perpage=="30"): echo 'selected'; endif; ?>>30</option>
                                            <option value="40" <?php if($record_perpage=="40"): echo 'selected'; endif; ?>>40</option>
                                        </select>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </header> <!-- card-header end// -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Email</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Phone No.</th>
                                        <th scope="col">Subject</th>
                                        <th scope="col">Message</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                </thead>
                                <tbody id="ruo-result">
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($message->email); ?></td>
                                            <td>
                                                <b>
                                                    <?php echo e($message->name); ?>

                                                </b>
                                            </td>
                                            <td><?php echo e($message->phone); ?></td>
                                            <td><?php echo e($message->subject); ?></td>
                                            <td><?php echo e($message->message); ?></td>
                                            <td><?php echo date('d-M-y h:m', strtotime($message->created_at)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- table-responsive //end -->
                    </div> <!-- card-body end// -->
                </div> <!-- card end// -->
                <div class="pagination-area mt-30 mb-50">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <?php echo e($messages->render()); ?>

                        </ul>
                    </nav>
                </div>
            <?php else: ?>
                <div class="d-flex justify-content-center align-items-center">
                    <h3>No Message Yet.</h3>
                </div>
            <?php endif; ?>
        </section> <!-- content-main end// -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/contactUsMessages.blade.php ENDPATH**/ ?>