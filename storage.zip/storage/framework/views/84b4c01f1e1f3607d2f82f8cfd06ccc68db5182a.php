<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Visitors Orders | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Visitors Orders List </h2>
                </div>
            </div>
            <?php if(count($orders) > 0): ?>
                <div class="card mb-4">
                    <header class="card-header">
                        <div class="row gx-3">
                            <div class="col-lg-4 col-md-4 me-auto">
                                <form class="searchform" method="POST" action="<?php echo e(route('Admin.get-v-order')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group">
                                        <input list="search_terms" type="text" name="id" class="form-control"
                                            placeholder="Search term">
                                        <button class="btn btn-light bg" type="submit"> <i
                                                class="material-icons md-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-lg-8 col-8 col-md-8 d-flex justify-content-end">
                                <form method="POST" action="<?php echo e(route('Admin.get-v-orders')); ?>" class="row">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-7 col-7 col-md-7">
                                        <select class="form-select" name="status" onchange="this.form.submit()">
                                            <option value="All" <?php if($status == 'All'): echo 'selected'; endif; ?>>All</option>
                                            <option value="Accepted" <?php if($status == 'Accepted'): echo 'selected'; endif; ?>>Accepted</option>
                                            <option value="Dispatched" <?php if($status == 'Dispatched'): echo 'selected'; endif; ?>>Dispatched</option>
                                            <option value="Completed" <?php if($status == 'Completed'): echo 'selected'; endif; ?>>Completed</option>
                                            <option value="Cancel" <?php if($status == 'Cancel'): echo 'selected'; endif; ?>>Cancel</option>
                                            <option value="Return" <?php if($status == 'Return'): echo 'selected'; endif; ?>>Return</option>
                                            <option value="New Order" <?php if($status == 'New Order'): echo 'selected'; endif; ?>>New Order</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-5 col-5 col-md-5">
                                        <select class="form-select" name="record" onchange="this.form.submit()">
                                            <option value="20" <?php if($record_perpage == '20'): echo 'selected'; endif; ?>>20</option>
                                            <option value="30" <?php if($record_perpage == '30'): echo 'selected'; endif; ?>>30</option>
                                            <option value="40" <?php if($record_perpage == '40'): echo 'selected'; endif; ?>>40</option>
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </header> <!-- card-header end// -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Date</th>
                                        <th scope="col" class="text-end"> Action </th>
                                    </tr>
                                </thead>
                                <tbody id="ruo-result">
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>SDVO#<?php echo e($order->id); ?></td>
                                            <td>
                                                <b>
                                                    <?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?>

                                                </b>
                                            </td>
                                            <td><?php echo e($order->email); ?></td>
                                            <td>$<?php echo e($order->bill); ?></td>
                                            <td>
                                                <?php if($order->status == 'Accepted'): ?>
                                                    <span class="badge rounded-pill alert-primary">Accepted</span>
                                                <?php elseif($order->status == 'Dispatched'): ?>
                                                    <span class="badge rounded-pill alert-info">Dispatched</span>
                                                <?php elseif($order->status == 'Completed'): ?>
                                                    <span class="badge rounded-pill alert-success">Completed</span>
                                                <?php elseif($order->status == 'Cancel'): ?>
                                                    <span class="badge rounded-pill alert-danger">Cancel</span>
                                                <?php else: ?>
                                                    <span class="badge rounded-pill alert-secondary">New Order</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('d-M-y', strtotime($order->created_at)); ?></td>
                                            <td class="text-end">
                                                <a href="<?php echo e(url('/admin/visitor-order-detail/' . $order->id)); ?>"
                                                    class="btn btn-md rounded font-sm">Detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- table-responsive //end -->
                    </div> <!-- card-body end// -->
                </div> <!-- card end// -->
                <div class="pagination-area mt-30 mb-50">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <?php echo e($orders->render()); ?>

                        </ul>
                    </nav>
                </div>
            <?php else: ?>
                <div class="d-flex justify-content-center align-items-center">
                    <h3>No Order Accepted Yet.</h3>
                </div>
            <?php endif; ?>
        </section> <!-- content-main end// -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/visitorsAcceptedOrders.blade.php ENDPATH**/ ?>