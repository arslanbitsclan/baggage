<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Products | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Products</h2>
                </div>
                <div>
                    <a href="<?php echo e(url('/admin/add-product')); ?>" class="btn btn-primary btn-sm rounded">Add New Product</a>
                </div>
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <div class="row gx-3">
                        <div class="col-lg-5 col-md-5 me-auto">
                            <form class="searchform" method="POST" action="<?php echo e(route('Admin.product-by-id')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input list="search_terms" type="text" name="id" class="form-control"
                                        placeholder="Search by ID">
                                    <button class="btn btn-light bg" type="submit"> <i
                                            class="material-icons md-search"></i></button>
                                </div>
                            </form>
                        </div>
                        <form class="col-lg-7 col-7 col-md-3 d-flex justify-content-end" action="<?php echo e(route('Admin.product-filter')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <div class="col-lg-3 col-3 col-md-3 mx-1">
                                    <select class="form-select" name="cat" onchange="this.form.submit()">
                                        <option value="All" <?php if($cat == 'All'): echo 'selected'; endif; ?>>All category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php if($cat == $category->id): echo 'selected'; endif; ?>><?php echo e($category->category_title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-3 col-3 col-md-3">
                                    <select class="form-select" name="filter" onchange="this.form.submit()">
                                        <option value="Latest added" <?php if($filter == 'Latest added'): echo 'selected'; endif; ?>>Latest added</option>
                                        <option value="Published" <?php if($filter == 'Published'): echo 'selected'; endif; ?>>Published</option>
                                        <option value="Not Published" <?php if($filter == 'Not Published'): echo 'selected'; endif; ?>>Not Published</option>
                                    </select>
                                </div>                                
                        </form>
                    </div>
                </header>
                <div class="card-body">
                    <div class="row gx-3 row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 row-cols-xxl-5">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <div class="card card-product-grid">
                                    <a href="javascript:void(0)" class="img-wrap"> <img
                                            src="<?php echo e(asset('uploads/' . $product->main_media)); ?>" alt="Product"> </a>
                                    <div class="form-check form-switch ms-4">
                                        <label class="form-check-label" for="toggle_<?php echo e($product->id); ?>">Publish</label>
                                        <input class="form-check-input" type="checkbox" id="toggle_<?php echo e($product->id); ?>"
                                            <?php if($product->is_publish == 'Publish'): ?> checked <?php endif; ?>
                                            onclick="product_publish(<?php echo e($product->id); ?>)">
                                    </div>
                                    <div class="info-wrap">
                                        <a class="title text-truncate"><?php echo e($product->title); ?></a>
                                        <div class="price mb-2">£<?php echo e($product->price); ?></div> <!-- price.// -->
                                        <a class="title text-truncate">SD<?php echo e($product->id); ?></a>
                                        <a href="<?php echo e(url('/admin/edit-product/' . $product->id)); ?>"
                                            class="btn btn-sm font-sm rounded btn-brand">
                                            <i class="material-icons md-edit"></i> Edit
                                        </a>
                                        <a href="<?php echo e(url('/admin/delete-product/' . $product->id)); ?>"
                                            class="btn btn-sm font-sm btn-light rounded">
                                            <i class="material-icons md-delete_forever"></i> Delete
                                        </a>
                                    </div>
                                </div> <!-- card-product  end// -->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- row.// -->
                </div> <!-- card-body end// -->
            </div> <!-- card end// -->
            <div class="pagination-area mt-30 mb-50">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php echo e($products->render()); ?>

                    </ul>
                </nav>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            function product_publish(id) {
                var toggle_check = $('#toggle_' + id).is(':checked');
                var value = '';
                if (toggle_check) {
                    value = 'Publish';
                } else {
                    value = 'Draft';
                }
                $.ajax({
                    url: "<?php echo e(url('/admin/product-publish')); ?>",
                    data: {
                        'id': id,
                        'value': value
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\baggage\baggage\resources\views/admin/products.blade.php ENDPATH**/ ?>