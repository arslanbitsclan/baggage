
<?php $__env->startPush('head'); ?>
    <title>Make Payment | Baggage factory</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(url('/')); ?>" rel="nofollow">Home</a>
                    <span></span> Order Confirm
                </div>
            </div>
        </div>
        <section class="pt-100 pb-100">
            <div class="container d-flex justify-content-center align-items-center">
                <div class="card col-lg-6">
                    <div class="card-header">
                        <h5 class="mb-0">Make Payment</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('stripe.payment')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <script
                              src="https://checkout.stripe.com/checkout.js"
                              class="stripe-button"
                              data-key="pk_test_51Laj1vHkcyJzI4kmHMUwLAnv4lJZUu7nfYTFz894Ff8JtaOebPJGHDktlWaBtX4tuAMHJ1CfeZIHxNUwuyVr640I00Vjg0x4qb"
                              data-name="Baggage Factory"
                              data-description="<?php echo e(session()->get('order_id')); ?>"
                              data-amount="<?php echo e(session()->get('order_bill') * 100); ?>"
                              data-label="Make Payment"
                              data-image="<?php echo e(asset('uploads/website/baggageLogo.jpg')); ?>"
                              data-currency="GBP">
                            </script>
                          </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/payments/stripeForm.blade.php ENDPATH**/ ?>