<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Currencies | Baggage Factory</title>
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Currencies </h2>
                    <p>Add, Edit or Delete a Currency</p>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            <form action="<?php echo e(url('/admin/add-currency')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-4">
                                    <label for="product_name" class="form-label">Name</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="name" name="name" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="symbol" class="form-label">Symbol</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="symbol" name="symbol" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="exchange_rate" class="form-label">Exchange Rate</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="exchange_rate" name="exchange_rate" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['exchange_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="code" class="form-label">Code</label>
                                    <input type="text" placeholder="Type here" class="form-control" id="code" name="code" required/>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="mb-4">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                    <small class="text-danger">
                                        <?php $__errorArgs = ['show'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </small>
                                </div>
                                <div class="d-grid">
                                    <button class="btn btn-primary">Create currency</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-10">
                            <div class="table-responsive">
                                <table class="table table-hover" id="">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Symbol</th>
                                            <th>Exchange Rate (£ 1=?)</th>
                                            <th>Code</th>
                                            <th>Status</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="row<?php echo e($currency->id); ?>">
                                                <td id="name_row<?php echo e($currency->id); ?>"><?php echo e($currency->name); ?></td>
                                                <td id="symbol_row<?php echo e($currency->id); ?>"><?php echo e($currency->symbol); ?></td>
                                                <td id="exchange_rate_row<?php echo e($currency->id); ?>"><?php echo e($currency->exchange_rate); ?></td>
                                                <td id="code_row<?php echo e($currency->id); ?>"><?php echo e($currency->code); ?></td>
                                                <td class="mb-1">
                                                    <div class="mb-1">
                                                        <select class="form-select" id="show_select_<?php echo e($currency->id); ?>"
                                                            onchange="show_currency('<?php echo e($currency->id); ?>')">
                                                            <option value="Active"
                                                                <?php if($currency->status == 'Active'): ?> Selected <?php endif; ?>>Active
                                                            </option>
                                                            <option value="Inactive"
                                                                <?php if($currency->status == 'Inactive'): ?> Selected <?php endif; ?>>Inactive
                                                            </option>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td class="d-flex justify-content-center align-items-center">
                                                    <button id="edit_button<?php echo e($currency->id); ?>" class="btn btn-info m-2" onclick="edit_row(<?php echo e($currency->id); ?>)"><i class="fas fa-pen text-white"></i></button>
                                                    <button id="save_button<?php echo e($currency->id); ?>" class="btn btn-success m-2" onclick="save_row(<?php echo e($currency->id); ?>)" style="display: none"><i class="fas fa-check text-white"></i></button>
                                                    <button id="loader<?php echo e($currency->id); ?>" class="btn btn-success m-2" style="display: none">
                                                        <span class="spinner-border spinner-border-sm text-white m-2" role="status" aria-hidden="true"></span>
                                                    </button>
                                                    <button class="btn btn-danger" onclick="delete_currency(<?php echo e($currency->id); ?>)"><i class="fas fa-trash text-white"></i></button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div> <!-- .col// -->
                    </div> <!-- .row // -->
                </div> <!-- card body .// -->
            </div> <!-- card .// -->
            <div class="pagination-area mt-30 mb-50">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php echo e($currencies->render()); ?>

                    </ul>
                </nav>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            function show_currency(id) {
                $.ajax({
                    url: "<?php echo e(url('/admin/show-currency')); ?>",
                    data: {
                        'id': id,
                        'status': $('#show_select_' + id + ' option:selected').val(),
                        '_token':'<?php echo e(csrf_token()); ?>'
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
            function delete_currency(id) {
                $.ajax({
                    url: "<?php echo e(url('/admin/delete-currency')); ?>",
                    data: {
                        'id': id,
                        '_token':'<?php echo e(csrf_token()); ?>'
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                            location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
            function edit_row(no) {
                document.getElementById("edit_button"+no).style.display="none";
                document.getElementById("save_button"+no).style.display="block";

                var name=document.getElementById("name_row"+no);
                var symbol=document.getElementById("symbol_row"+no);
                var exchange_rate=document.getElementById("exchange_rate_row"+no);
                var code=document.getElementById("code_row"+no);

                var name_data=name.innerHTML;
                var symbol_data=symbol.innerHTML;
                var exchange_rate_data=exchange_rate.innerHTML;
                var code_data=code.innerHTML;

                name.innerHTML="<input type='text' class='mb-2' id='name_text"+no+"' value='"+name_data+"'>";
                symbol.innerHTML="<input type='text' class='mb-2' id='symbol_text"+no+"' value='"+symbol_data+"'>";
                exchange_rate.innerHTML="<input type='text' class='mb-2' id='exchange_rate_text"+no+"' value='"+exchange_rate_data+"'>";
                code.innerHTML="<input type='text' class='mb-2' id='code_text"+no+"' value='"+code_data+"'>";
            }
            function save_row(no) {
                var name_val=document.getElementById("name_text"+no).value;
                var symbol_val=document.getElementById("symbol_text"+no).value;
                var exchange_rate_val=document.getElementById("exchange_rate_text"+no).value;
                var code_val=document.getElementById("code_text"+no).value;
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(url('/admin/edit-currency')); ?>",
                    data: {
                        'id':no,
                        'name':name_val,
                        'symbol':symbol_val,
                        'exchange_rate':exchange_rate_val,
                        'code':code_val,
                        '_token':'<?php echo e(csrf_token()); ?>'
                    },
                    beforeSend: function(){
                        document.getElementById("save_button"+no).style.display="none";
                        document.getElementById("loader"+no).style.display="block";
                    },
                    success: function (response) {
                        if(response.success==true){
                            iziToast.success({
                                position: 'topRight',
                                message: response.message,
                            });
                            document.getElementById("name_row"+no).innerHTML=name_val;
                            document.getElementById("symbol_row"+no).innerHTML=symbol_val;
                            document.getElementById("exchange_rate_row"+no).innerHTML=exchange_rate_val;
                            document.getElementById("code_row"+no).innerHTML=code_val;

                            document.getElementById("edit_button"+no).style.display="block";
                            document.getElementById("save_button"+no).style.display="none";
                            document.getElementById("loader"+no).style.display="none";
                        }else{
                            iziToast.error({
                                position: 'topRight',
                                message: response.message,
                            });
                        }
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/currencies.blade.php ENDPATH**/ ?>