<?php
$views = \App\Models\Blogs::where('id', '=', $blog->id)
    ->where('status', '=', 'Active')
    ->first()->views;
$views++;
\App\Models\Blogs::where('id', '=', $blog->id)
    ->where('status', '=', 'Active')
    ->update(['views' => $views]);
?>

<?php $__env->startPush('head'); ?>
    <title><?php echo e($blog->title); ?> | Baggage Factory</title>
    <style>
        .l2-text {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            /* number of lines to show */
            -webkit-box-orient: vertical;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
    <?php
        $content = \App\Models\CMS::where('page', '=', 'blog_detail')->first();
    ?>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(url('/')); ?>" rel="nofollow">Home</a>
                    <span></span> <a href="<?php echo e(url('/blog')); ?>" rel="nofollow">Blog</a>
                    <span></span> <?php echo e($blog->blog_categories->name); ?>

                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container custom">
                <div class="row">
                    <div class="col-lg-10 m-auto">
                        <div class="single-page pl-30">
                            <div class="single-header style-2">
                                <h1 class="mb-30 l2-text" title="<?php echo e($blog->title); ?>"><?php echo e($blog->title); ?></h1>
                                <div class="single-header-meta">
                                    <div class="entry-meta meta-1 font-xs mt-15 mb-15">
                                        <span class="post-on"><?php echo e(formatted_date($blog->created_at, 'd.m.Y')); ?></span>
                                        <span class="hit-count  has-dot"><?php echo e($blog->views); ?> Views</span>
                                    </div>
                                    <div class="social-icons single-share">
                                        <ul class="text-grey-5 d-inline-block">
                                            <li><strong class="mr-10">Share this:</strong></li>
                                            <li class="social-facebook"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-facebook.svg')); ?>"
                                                        alt=""></a>
                                            </li>
                                            <li class="social-twitter"> <a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-twitter.svg')); ?>"
                                                        alt=""></a>
                                            </li>
                                            <li class="social-instagram"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-instagram.svg')); ?>"
                                                        alt=""></a>
                                            </li>
                                            <li class="social-linkedin"><a href="#"><img
                                                        src="<?php echo e(asset('assets/imgs/theme/icons/icon-pinterest.svg')); ?>"
                                                        alt=""></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <figure class="single-thumbnail">
                                <img src="<?php echo e(asset('uploads/' . $blog->media)); ?>" alt="">
                            </figure>
                            <div class="single-content">
                                <?php echo $blog->description; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php if($content->ad_status == 'Show'): ?>
            <section class="mt-50 mb-50">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="container">
                                <div class="banner-img banner-big wow fadeIn animated f-none">
                                    <img src="<?php echo e(asset('/uploads/' . $content->ad)); ?>" alt="">
                                    <div class="banner-text d-md-block d-none" style="margin-left: -2%;margin-top: 9.1%;">
                                        <a href="<?php if(empty($content->category_slug) && empty($content->sub_category_slug)): ?> <?php echo e(url('/shop')); ?>

                                            <?php elseif(!empty($content->category_slug) && empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug)); ?>

                                            <?php elseif(!empty($content->category_slug) && !empty($content->sub_category_slug)): ?>
                                                <?php echo e(url('/shop/' . $content->category_slug . '/' . $content->sub_category_slug)); ?> <?php endif; ?>"
                                            class="btn ">Learn More <i class="fi-rs-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/blog-detail.blade.php ENDPATH**/ ?>