<?php if(session()->has('admin')): ?>
    
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <?php $__env->startPush('head'); ?>
                <title>SDRO<?php echo e($order->id); ?> | Baggage Factory</title>
                <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
            <?php $__env->stopPush(); ?>
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Order detail</h2>
                    <p>Details for Order ID: SDRO<?php echo e($order->id); ?></p>
                </div>
            </div>
            <div class="card">
                <header class="card-header">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6 mb-lg-0 mb-15">
                            <span>
                                <i class="material-icons md-calendar_today"></i> <b><?php echo date('d-M-y', strtotime($order->created_at)); ?></b>
                            </span> <br>
                            <small class="text-muted">Order ID: SDRO<?php echo e($order->id); ?></small>
                        </div>
                        <div class="col-lg-6 col-md-6 ms-auto text-md-end d-flex justify-content-between">
                            <span class="">Current Status: <b><?php echo e($order->status); ?></b></span>
                            <?php if($order->status == 'New Order'): ?>
                                <button id="accept_btn" class="btn btn-md rounded font-sm"
                                    onclick="change_status('<?php echo e($order->customers->email_addr); ?>',<?php echo e($order->id); ?>,'Accepted')">Accept</button>
                                <button id="loader_accept" class="btn btn-md rounded font-sm" style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                                <button id="cancel_btn" class="btn btn-md rounded font-sm bg-danger"
                                    onclick="change_status('<?php echo e($order->customers->email_addr); ?>',<?php echo e($order->id); ?>,'Cancel')">Cancel</button>
                                <button id="loader_cancel" class="btn btn-md rounded font-sm bg-danger"
                                    style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                            <?php elseif($order->status == 'Accepted'): ?>
                                <button id="dispatch_btn" class="btn btn-md rounded font-sm" data-bs-toggle="modal" data-bs-target="#shippingModal"
                                    >Dispatch</button>
                                <button id="loader_dispatch" class="btn btn-md rounded font-sm" style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                                <button id="cancel_btn" class="btn btn-md rounded font-sm bg-danger" data-bs-toggle="modal" data-bs-target="#cancelModal"
                                    >Cancel</button>
                                <button id="loader_cancel" class="btn btn-md rounded font-sm bg-danger"
                                    style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                            <?php elseif($order->status == 'Dispatched'): ?>
                                <button id="complete_btn" class="btn btn-md rounded font-sm"
                                    onclick="change_status('<?php echo e($order->customers->email_addr); ?>',<?php echo e($order->id); ?>,'Completed')">Completed</button>
                                <button id="loader_complete" class="btn btn-md rounded font-sm" style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                                <button id="return_btn" class="btn btn-md rounded font-sm bg-danger" data-bs-toggle="modal" data-bs-target="#returnModal"
                                >Return</button>
                                <button id="loader_return" class="btn btn-md rounded font-sm bg-danger"
                                    style="display: none">
                                    <span class="spinner-border spinner-border-sm text-white m-2" role="status"
                                        aria-hidden="true"></span>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </header> <!-- card-header end// -->
                <div class="card-body">
                    <div class="row mb-50 mt-20 order-info-wrap">
                        <div class="col-md-4">
                            <article class="icontext align-items-start">
                                <span class="icon icon-sm rounded-circle bg-primary-light">
                                    <i class="text-primary material-icons md-person"></i>
                                </span>
                                <div class="text">
                                    <h6 class="mb-1">Customer</h6>
                                    <p class="mb-1">
                                        <?php echo e($order->customers->first_name); ?> <?php echo e($order->customers->last_name); ?><br>
                                        <?php echo e($order->customers->email_addr); ?> <br>
                                        <?php echo e($order->customers->contact_number); ?>

                                    </p>
                                </div>
                            </article>
                        </div> <!-- col// -->
                        <?php if(!empty($order->order_shipping)): ?>
                            <div class="col-md-4">
                                <article class="icontext align-items-start">
                                    <span class="icon icon-sm rounded-circle bg-primary-light">
                                        <i class="text-primary material-icons md-local_shipping"></i>
                                    </span>
                                    <div class="text">
                                        <h6 class="mb-1">Shipping info</h6>
                                        <p class="mb-1">
                                            Shipping: Free <br> Company: <?php echo e($order->order_shipping->shipping_companies->name); ?> <br> Tracking No:
                                            <?php echo e($order->order_shipping->tracking_id); ?>

                                        </p>
                                    </div>
                                </article>
                            </div> <!-- col// -->
                        <?php endif; ?>                        
                        <div class="col-md-4">
                            <article class="icontext align-items-start">
                                <span class="icon icon-sm rounded-circle bg-primary-light">
                                    <i class="text-primary material-icons md-place"></i>
                                </span>
                                <div class="text">
                                    <h6 class="mb-1">Deliver to</h6>
                                    <p class="mb-1">
                                        <?php if($order->is_same_as_billing == 1): ?>
                                            <?php echo e($order->customers->city); ?> <br><?php echo e($order->customers->address1); ?> <br>
                                            <?php echo e($order->customers->postal_code); ?>

                                        <?php else: ?>
                                            <?php echo e($order->order_billing_addresses->city); ?>

                                            <br><?php echo e($order->order_billing_addresses->address1); ?> <br>
                                            <?php echo e($order->order_billing_addresses->postal_code); ?>

                                        <?php endif; ?>

                                    </p>
                                </div>
                            </article>
                        </div> <!-- col// -->
                    </div> <!-- row // -->
                    <div class="row">
                        <div class="col-lg-7">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th width="40%">Product</th>
                                            <th width="20%">Unit Price</th>
                                            <th width="20%">Quantity</th>
                                            <th width="20%" class="text-end">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a class="itemside" href="#">
                                                        <div class="left">
                                                            <img src="<?php echo e(asset('uploads/' . $item->products->main_media)); ?>"
                                                                width="40" height="40" class="img-xs"
                                                                alt="Item">
                                                        </div>
                                                        <div class="info"> <?php echo e($item->products->title); ?> </div>
                                                    </a>
                                                </td>
                                                <td> £<?php echo e($item->sub_bill); ?> </td>
                                                <td> <?php echo e($item->qty); ?> </td>
                                                <td class="text-end"> $<?php echo e($item->sub_bill); ?> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="4">
                                                <article class="float-end">
                                                    <dl class="dlist">
                                                        <dt>Subtotal:</dt>
                                                        <dd>£<?php echo e($order->bill); ?></dd>
                                                    </dl>
                                                    <dl class="dlist">
                                                        <dt>Shipping cost:</dt>
                                                        <dd>Free</dd>
                                                    </dl>
                                                    <dl class="dlist">
                                                        <dt>Grand total:</dt>
                                                        <dd> <b class="h5">£<?php echo e($order->bill); ?></b> </dd>
                                                    </dl>
                                                    <dl class="dlist">
                                                        <dt class="text-muted">Status:</dt>
                                                        <dd>
                                                            <span
                                                                class="badge rounded-pill alert-success text-warning"><?php echo e($order->payment_status); ?></span>
                                                        </dd>
                                                    </dl>
                                                </article>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div> <!-- table-responsive// -->
                        </div> <!-- col// -->
                        <div class="col-lg-1"></div>
                        <div class="col-lg-4">
                            <div class="box shadow-sm bg-light">
                                <h6 class="mb-15">Payment info</h6>
                                <p>
                                    <?php echo e($order->payment_method); ?>

                                </p>
                            </div>
                            <?php if(!empty($order->cancel_reason)): ?>
                                <div class="box shadow-sm bg-light">
                                    <h6 class="mb-15">Cancel Reason</h6>
                                    <p>
                                        <?php echo e($order->cancel_reason); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($order->return_reason)): ?>
                                <div class="box shadow-sm bg-light">
                                    <h6 class="mb-15">Return Reason</h6>
                                    <p>
                                        <?php echo e($order->return_reason); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($order->note)): ?>
                                <div class="h-25 pt-4">
                                    <div class="mb-3">
                                        <label>Notes</label>
                                        <textarea class="form-control" name="notes" id="notes" placeholder="Type some note" readonly><?php echo e($order->note); ?></textarea>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div> <!-- col// -->
                    </div>
                </div> <!-- card-body end// -->
            </div>
        </section> <!-- content-main end// -->
        <section>
            <div class="modal fade custom-modal" id="shippingModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Shipping Detail</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="shipping_form">
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                    <input type="hidden" name="email" value="<?php echo e($order->customers->email_addr); ?>">
                                    <input type="hidden" name="status" value="Dispatched">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tracking No</label>
                                    <input type="text" class="form-control" name="tracking_id" placeholder="Tracking No." required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Expected Days</label>
                                    <input class="form-control" type="text" name="days" placeholder="Enter Days" required>
                                </div>                                        
                                <div class="mb-3">
                                    <label class="form-label">Shipping Company</label>
                                    <select class="form-select" name="shipping_companies_id" required>
                                        <?php $__currentLoopData = $shipping_companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping_company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($shipping_company->id); ?>"><?php echo e($shipping_company->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <input type="submit" class="btn btn-primary w-100" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade custom-modal" id="returnModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Returning Reason</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="return_form">
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                    <input type="hidden" name="email" value="<?php echo e($order->customers->email_addr); ?>">
                                    <input type="hidden" name="status" value="Return">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Returning Reason</label>
                                    <input type="text" class="form-control" name="return_reason" placeholder="Returning reason" required>
                                </div>                                
                                <div class="mb-3">
                                    <input type="submit" class="btn btn-primary w-100" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade custom-modal" id="cancelModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Canceling Reason</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="cancel_form">
                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                    <input type="hidden" name="email" value="<?php echo e($order->customers->email_addr); ?>">
                                    <input type="hidden" name="status" value="Cancel">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Canceling Reason</label>
                                    <input type="text" class="form-control" name="Cancel_reason" placeholder="Canceling reason" required>
                                </div>                                
                                <div class="mb-3">
                                    <input type="submit" class="btn btn-primary w-100" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            function change_status(email, id, status) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('Admin.ru-change-order-status')); ?>",
                    data: {
                        'status': status,
                        'id': id,
                        'email': email
                    },
                    beforeSend: function() {
                        if (status == 'Accepted') {
                            document.getElementById("accept_btn").style.display = "none";
                            document.getElementById("loader_accept").style.display = "block";
                        } else if (status == 'Cancel') {
                            document.getElementById("cancel_btn").style.display = "none";
                            document.getElementById("loader_cancel").style.display = "block";
                        } else if (status == 'Dispatched') {
                            document.getElementById("dispatch_btn").style.display = "none";
                            document.getElementById("loader_dispatch").style.display = "block";
                        } else if (status == 'Completed') {
                            document.getElementById("complete_btn").style.display = "none";
                            document.getElementById("loader_complete").style.display = "block";
                        } else if (status == 'Return') {
                            document.getElementById("return_btn").style.display = "none";
                            document.getElementById("loader_return").style.display = "block";
                        }
                    },
                    success: function(response) {
                        if (response.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: response.message,
                            });
                            window.location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: response.message,
                            });
                        }
                    }
                });
            }
            $("#shipping_form").submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var url = "<?php echo e(route('Admin.ru-change-order-status-dispatched')); ?>";
                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(),
                    success: function(response) {
                        if (response.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: response.message
                            });
                            window.location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: response.message
                            });
                        }
                    },
                    error: function(response) {
                        iziToast.error({
                            position: 'topRight',
                            message: response.responseJSON.errors
                        });
                    }
                });
            });
            $("#return_form").submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var url = "<?php echo e(route('Admin.ru-change-order-status-return')); ?>";
                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(),
                    success: function(response) {
                        if (response.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: response.message
                            });
                            window.location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: response.message
                            });
                        }
                    },
                    error: function(response) {
                        iziToast.error({
                            position: 'topRight',
                            message: response.responseJSON.errors
                        });
                    }
                });
            });
            $("#cancel_form").submit(function(e) {
                e.preventDefault();
                var form = $(this);
                var url = "<?php echo e(route('Admin.ru-change-order-status-cancel')); ?>";
                $.ajax({
                    type: "POST",
                    url: url,
                    data: form.serialize(),
                    success: function(response) {
                        if (response.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: response.message
                            });
                            window.location.reload();
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: response.message
                            });
                        }
                    },
                    error: function(response) {
                        iziToast.error({
                            position: 'topRight',
                            message: response.responseJSON.errors
                        });
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/regUserOrderDetail.blade.php ENDPATH**/ ?>