<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Sent Mails | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Sent Mails List </h2>
                </div>
            </div>
            <?php if(count($sent_mails)>0): ?>
                <div class="card mb-4">
                    <header class="card-header">
                        <div class="row gx-3">
                            <div class="col-lg-9 col-md-9 me-auto">
                                <form class="searchform" method="POST" action="<?php echo e(route('Admin.sent-mails-search')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group">
                                        <input list="search_terms" type="text" name="id" class="form-control" placeholder="type">
                                        <button class="btn btn-light bg" type="submit"> <i
                                                class="material-icons md-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-lg-3 col-3 col-md-3 d-flex justify-content-end">
                                <div class="col-lg-3 col-3 col-md-3">
                                    <form method="POST" action="<?php echo e(route('Admin.sent-mails-pagination')); ?>" class="row">
                                        <?php echo csrf_field(); ?>
                                        <select class="form-select" name="record" onchange="this.form.submit()">
                                            <option value="20" <?php if($record_perpage=="20"): echo 'selected'; endif; ?>>20</option>
                                            <option value="30" <?php if($record_perpage=="30"): echo 'selected'; endif; ?>>30</option>
                                            <option value="40" <?php if($record_perpage=="40"): echo 'selected'; endif; ?>>40</option>
                                        </select>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </header> <!-- card-header end// -->
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Email</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Subject</th>
                                        <th scope="col">Order Number</th>
                                        <th scope="col">Bill</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                </thead>
                                <tbody id="ruo-result">
                                    <?php $__currentLoopData = $sent_mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sent_mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sent_mail->mail); ?></td>
                                            <td>
                                                <b>
                                                    <?php echo e($sent_mail->name); ?>

                                                </b>
                                            </td>
                                            <td><?php echo e($sent_mail->subject); ?></td>
                                            <td><?php echo e($sent_mail->order_number); ?></td>
                                            <td>$<?php echo e($sent_mail->bill); ?></td>
                                            <td><?php echo date('d-M-y h:m:s', strtotime($sent_mail->created_at)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- table-responsive //end -->
                    </div> <!-- card-body end// -->
                </div> <!-- card end// -->
                <div class="pagination-area mt-30 mb-50">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <?php echo e($sent_mails->render()); ?>

                        </ul>
                    </nav>
                </div>
            <?php else: ?>
                <div class="d-flex justify-content-center align-items-center">
                    <h3>No Mails Yet.</h3>
                </div>
            <?php endif; ?>
        </section> <!-- content-main end// -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/sent-mails.blade.php ENDPATH**/ ?>