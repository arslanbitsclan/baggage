<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Products Reviews | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Reviews</h2>
                </div>
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <div class="row gx-3">
                        <div class="col-lg-5 col-md-5 me-auto">
                            <form class="searchform" method="POST" action="<?php echo e(route('Admin.reviews-by-id')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input list="search_terms" type="text" name="id" class="form-control"
                                        placeholder="Search by ID">
                                    <button class="btn btn-light bg" type="submit"> <i
                                            class="material-icons md-search"></i></button>
                                </div>
                            </form>
                        </div>
                        <form class="col-lg-6 col-6 col-md-3 d-flex justify-content-end" action="<?php echo e(route('Admin.reviews-by-status')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                               
                                <div class="col-lg-4 col-4 col-md-4 mx-1">
                                    <select class="form-select" name="status" onchange="this.form.submit()">
                                        <option value="All" <?php if($status == 'All'): echo 'selected'; endif; ?>>All</option>
                                        <option value="Approved" <?php if($status == 'Approved'): echo 'selected'; endif; ?>>Approved</option>
                                        <option value="Disapproved" <?php if($status == 'Disapproved'): echo 'selected'; endif; ?>>Disapproved</option>
                                        <option value="Pending" <?php if($status == 'Pending'): echo 'selected'; endif; ?>>Pending</option>
                                    </select>
                                </div>
                                <div class="col-lg-2 col-2 col-md-4">
                                    <select class="form-select" name="record" onchange="this.form.submit()">
                                        <option value="20" <?php if($record_perpage == 20): echo 'selected'; endif; ?>>20</option>
                                        <option value="30" <?php if($record_perpage == 30): echo 'selected'; endif; ?>>30</option>
                                        <option value="40" <?php if($record_perpage == 40): echo 'selected'; endif; ?>>40</option>
                                    </select>
                                </div>                                
                        </form>
                    </div>
                </header>
                <!-- card-header end// -->
                <div class="card-body">
                    <?php if(!empty($reviews->toArray())): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Product</th>
                                    <th>Name</th>
                                    <th>comment</th>
                                    <th>Rating</th>
                                    <th>Date</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($review->id); ?></td>
                                        <td><b><?php echo e(count_text($review->products->title)); ?></b></td>
                                        <td><?php echo e($review->name); ?></td>
                                        <td><?php echo e($review->comment); ?></td>
                                        <td>
                                            <ul class="rating-stars">
                                                <li style="width: <?php echo e(($review->rating / 5) * 100); ?>%;" class="stars-active">
                                                    <img src="<?php echo e(asset('assets/admin/imgs/icons/stars-active.svg')); ?>"
                                                        alt="stars" />
                                                </li>
                                                <li>
                                                    <img src="<?php echo e(asset('assets/admin/imgs/icons/starts-disable.svg')); ?>"
                                                        alt="stars" />
                                                </li>
                                            </ul>
                                        </td>
                                        <td><?php echo e(formatted_date($review->created_at, 'd.m.y')); ?></td>
                                        <td class="text-center">
                                            <select class="form-select" id="status_select_<?php echo e($review->id); ?>"
                                                onchange="change_status(<?php echo e($review->id); ?>)">
                                                <option value="Approved" <?php if($review->status == 'Approved'): ?> selected <?php endif; ?>>
                                                    Approved
                                                </option>
                                                <option value="Disapproved"
                                                    <?php if($review->status == 'Disapproved'): ?> selected <?php endif; ?>>Disapproved
                                                </option>
                                                <option value="Pending" <?php if($review->status == 'Pending'): ?> selected <?php endif; ?>>
                                                    Pending
                                                </option>
                                            </select>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div> <!-- table-responsive//end -->
                    <?php else: ?>
                    <div class="d-flex justify-content-center align-items-center">
                        <h3>No Reviews Yet.</h3>
                    </div>
                    <?php endif; ?>                    
                </div>
                <!-- card-body end// -->
            </div>
            <div class="pagination-area mt-30 mb-50">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-start">
                        <?php echo e($reviews->render()); ?>

                    </ul>
                </nav>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('footer'); ?>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            function change_status(id) {
                $.ajax({
                    url: "<?php echo e(route('Admin.change-review-status')); ?>",
                    data: {
                        'id': id,
                        'status': $('#status_select_' + id + ' option:selected').val()
                    },
                    type: 'POST',
                    success: function(data) {
                        if (data.success) {
                            iziToast.success({
                                position: 'topRight',
                                message: data.message,
                            });
                        } else {
                            iziToast.error({
                                position: 'topRight',
                                message: data.message,
                            });
                        }
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/productReviews.blade.php ENDPATH**/ ?>