<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Subscribers | Baggage Factory</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Subscribers</h2>
                </div>
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <div class="row gx-3">
                        <div class="col-lg-5 col-md-5 me-auto">
                            <form class="searchform" method="POST" action="<?php echo e(route('Admin.used-coupons-term')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input list="search_terms" type="text" name="term" class="form-control"
                                        placeholder="Search by term">
                                    <button class="btn btn-light bg" type="submit"> <i
                                            class="material-icons md-search"></i></button>
                                </div>
                            </form>
                        </div>
                        <form class="col-lg-6 col-6 col-md-3 d-flex justify-content-end"
                            action="<?php echo e(route('Admin.used-coupons-post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-2 col-2 col-md-4">
                                <select class="form-select" name="record" onchange="this.form.submit()">
                                    <option value="20" <?php if($record_perpage == 20): echo 'selected'; endif; ?>>20</option>
                                    <option value="30" <?php if($record_perpage == 30): echo 'selected'; endif; ?>>30</option>
                                    <option value="40" <?php if($record_perpage == 40): echo 'selected'; endif; ?>>40</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </header>
                <!-- card-header end// -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Email</th>
                                    <!-- <th>Action</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($email->emails); ?></td>
                                        <!-- <td><button type="button" class="btn btn-md rounded font-sm hover-up">Send Mail</button></td> -->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div> <!-- table-responsive//end -->
                </div>
                <!-- card-body end// -->
            </div>
            <div class="pagination-area mt-30 mb-50">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-start">
                        <?php if(!empty($coupons)): ?>
                            <?php echo e($emails->render()); ?>

                        <?php endif; ?>

                    </ul>
                </nav>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/subscribers.blade.php ENDPATH**/ ?>