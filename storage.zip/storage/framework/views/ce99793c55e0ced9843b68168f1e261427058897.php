<?php if(session()->has('admin')): ?>
    
    <?php $__env->startPush('head'); ?>
        <title>Admin Dashboard | Baggage Factory</title>
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('section'); ?>
        <?php
            $admin = session()->get('admin');
        ?>
        <section class="content-main">
            <div class="content-header">
                <div>
                    <h2 class="content-title card-title">Dashboard </h2>
                    <p>Whole data about your business here</p>
                </div>
                <!-- <div>
                    <a href="#" class="btn btn-primary"><i class="text-muted material-icons md-post_add"></i>Create
                        report</a>
                </div> -->
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="card card-body mb-4">
                        <article class="icontext">
                            <span class="icon icon-sm rounded-circle bg-primary-light"><i
                                    class="text-primary material-icons md-monetization_on"></i></span>
                            <div class="text">
                                <h6 class="mb-1 card-title">Revenue</h6>
                                <span>£<?php echo e($sum); ?></span>
                                <span class="text-sm">
                                    Shipping fees are not included
                                </span>
                            </div>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card card-body mb-4">
                        <article class="icontext">
                            <span class="icon icon-sm rounded-circle bg-success-light"><i
                                    class="text-success material-icons md-local_shipping"></i></span>
                            <div class="text">
                                <h6 class="mb-1 card-title">Orders</h6> <span><?php echo e($order_count); ?></span>
                                <span class="text-sm">
                                    Excluding orders in transit
                                </span>
                            </div>
                        </article>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card card-body mb-4">
                        <article class="icontext">
                            <span class="icon icon-sm rounded-circle bg-warning-light"><i
                                    class="text-warning material-icons md-qr_code"></i></span>
                            <div class="text">
                                <h6 class="mb-1 card-title">Products</h6> <span><?php echo e(count($products)); ?></span>
                                <span class="text-sm">
                                    In <?php echo e(count($categories)); ?> Categories
                                </span>
                            </div>
                        </article>
                    </div>
                </div>
                <!-- <div class="col-lg-3">
                    <div class="card card-body mb-4">
                        <article class="icontext">
                            <span class="icon icon-sm rounded-circle bg-info-light"><i
                                    class="text-info material-icons md-shopping_basket"></i></span>
                            <div class="text">
                                <h6 class="mb-1 card-title">Monthly Earning</h6> <span>£0</span>
                                <span class="text-sm">
                                    Based in your local time.
                                </span>
                            </div>
                        </article>
                    </div>
                </div> -->
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <h4 class="card-title">Register User Latest Orders</h4>
                    <div class="row align-items-center">
                        <div class="col-md-2 col-6">
                            <input type="date" value="02.05.2021" class="form-control">
                        </div>
                    </div>
                </header>
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="align-middle" scope="col">Order ID</th>
                                        <th class="align-middle" scope="col">Billing Name</th>
                                        <th class="align-middle" scope="col">Date</th>
                                        <th class="align-middle" scope="col">Total</th>
                                        <th class="align-middle" scope="col">Payment Method</th>
                                        <th class="align-middle" scope="col">View Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="javascript:void(0)" class="fw-bold">SDRO#<?php echo e($order->id); ?></a>
                                            </td>
                                            <td><?php echo e($order->customers->first_name); ?> <?php echo e($order->customers->last_name); ?></td>
                                            <td>
                                                <?php echo date('d-M-y', strtotime($order->created_at)); ?>

                                            </td>
                                            <td>
                                                £<?php echo e($order->bill); ?>

                                            </td>
                                            <td>
                                                <i class="material-icons md-payment font-xxl text-muted mr-5"></i>
                                                <?php echo e($order->payment_method); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/admin/register-user-order-detail/' . $order->id)); ?>"
                                                    class="btn btn-xs"> View details</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div> <!-- table-responsive end// -->
                </div>
            </div>
            <div class="card mb-4">
                <header class="card-header">
                    <h4 class="card-title">Visitors latest Orders</h4>
                    <div class="row align-items-center">
                        <div class="col-md-2 col-6">
                            <input type="date" value="02.05.2021" class="form-control">
                        </div>
                    </div>
                </header>
                <div class="card-body">
                    <div class="table-responsive">
                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="align-middle" scope="col">Order ID</th>
                                        <th class="align-middle" scope="col">Billing Name</th>
                                        <th class="align-middle" scope="col">Date</th>
                                        <th class="align-middle" scope="col">Total</th>
                                        <th class="align-middle" scope="col">Payment Method</th>
                                        <th class="align-middle" scope="col">View Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $vistors_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistors_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="javascript:void(0)"
                                                    class="fw-bold">SDVO#<?php echo e($vistors_order->id); ?></a> </td>
                                            <td><?php echo e($vistors_order->first_name); ?> <?php echo e($vistors_order->last_name); ?></td>
                                            <td>
                                                <?php echo date('d-M-y', strtotime($vistors_order->created_at)); ?>

                                            </td>
                                            <td>
                                                £<?php echo e($vistors_order->bill); ?>

                                            </td>
                                            <td>
                                                <i class="material-icons md-payment font-xxl text-muted mr-5"></i>
                                                <?php echo e($vistors_order->payment_method); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/admin/visitor-order-detail/' . $vistors_order->id)); ?>"
                                                    class="btn btn-xs"> View details</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div> <!-- table-responsive end// -->
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
<?php else: ?>
    <script>
        window.location.href = "<?php echo e(url('/admin/login')); ?>";
    </script>
<?php endif; ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/admin/index.blade.php ENDPATH**/ ?>