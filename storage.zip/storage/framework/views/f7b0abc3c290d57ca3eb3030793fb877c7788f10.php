<?php $__env->startPush('head'); ?>
    <title>Wishlist | Baggage Factory</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- FontAwesome 6.1.1 CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(url('/')); ?>" rel="nofollow">Home</a>
                    <span></span> Your Wishlist
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive">
                            <?php if(!empty($wishlists)): ?>
                                <table class="table shopping-summery text-center">
                                    <thead>
                                        <tr class="main-heading">
                                            <th scope="col" colspan="2">Product</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">Stock Status</th>
                                            <th scope="col">Action</th>
                                            <th scope="col">Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($product->id == $item['products_id']): ?>
                                                        <td class="image product-thumbnail"><img
                                                                src="<?php echo e(asset('uploads/' . $product->main_media)); ?>"
                                                                alt="#">
                                                        </td>
                                                        <td class="product-des product-name">
                                                            <h5 class="product-name"><a
                                                                    href="<?php echo e(url('/product-detail/' . $product->id)); ?>"><?php echo e($product->title); ?></a>
                                                            </h5>
                                                            <?php if($product->content != 0): ?>
                                                                <p class="font-xs"><?php echo e($product->content); ?></p>
                                                            <?php endif; ?>
                                                        </td>
                                                        <?php
                                                            $price = 0;
                                                        ?>
                                                        <td class="price" data-title="Price"><span><?php if($product->sale_price > 0): ?>
                                                                    <?php echo e(currency_converter($product->sale_price)); ?>

                                                                    <?php
                                                                        $price = $product->sale_price;
                                                                    ?>
                                                                <?php else: ?>
                                                                    <?php echo e(currency_converter($product->price)); ?>

                                                                    <?php
                                                                        $price = $product->price;
                                                                    ?>
                                                                <?php endif; ?> </span></td>
                                                        <td class="text-center" data-title="Stock">
                                                            <span
                                                                class="color3 font-weight-bold"><?php echo e($product->stock_availability); ?></span>
                                                        </td>
                                                        <?php if($product->stock_availability == 'In Stock'): ?>
                                                            <td class="text-right" data-title="Cart">
                                                                <button class="btn btn-sm"
                                                                    onclick="addToCart(<?php echo e($product->id); ?>,<?php echo e($price); ?>,1)"><i
                                                                        class="fi-rs-shopping-bag mr-5"></i>Add to
                                                                    cart</button>
                                                            </td>
                                                        <?php else: ?>
                                                            <td class="text-right" data-title="Cart">
                                                                <button class="btn btn-sm btn-secondary"><i
                                                                        class="fi-rs-headset mr-5"></i>Contact
                                                                    Us</button>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td class="action" data-title="Remove"><a
                                                            onclick="deleteWishlist(<?php echo e($product->id); ?>)"><i
                                                                class="fi-rs-trash"></i></a></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="container d-flex justify-content-center align-items-center">
                                    <h1 class="text-black-50"><i class="fa fa-heart-circle-exclamation"></i> Empty Wishlist</h1>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
    <!-- (Optional) Use CSS or JS implementation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        function addToCart(id, price, qty) {
            price = price * qty;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                method: "post",
                url: "<?php echo e(url('/AddToCart')); ?>",
                data: {
                    "product_id": id,
                    "product_price": price,
                    "product_qty": qty
                },
                success: function(response) {
                    if (response.success) {
                        iziToast.success({
                            position: 'topRight',
                            message: response.message
                        });
                        $('#cartheading').html(response.qty);
                    } else {
                        iziToast.warning({
                            position: 'topRight',
                            message: response.message
                        });
                    }
                }
            });
        }

        function deleteWishlist(id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                method: "post",
                url: "<?php echo e(url('/delete-wishlist')); ?>",
                data: {
                    "product_id": id
                },
                success: function(response) {
                    if (response.success) {
                        iziToast.success({
                            position: 'topRight',
                            message: response.message
                        });
                        window.location.reload();
                    } else {
                        iziToast.warning({
                            position: 'topRight',
                            message: response.message
                        });
                    }
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\baggage\resources\views/wishlist.blade.php ENDPATH**/ ?>